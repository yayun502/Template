# Wafer Patch BBox Mapper v2

此版本在初版加入 **跨 overlap patch 的 circular class-wise NMS**。

你的設定為：

```text
patch_width = 1024
stride = 512
```

相鄰 patch 有 50% overlap，因此同一個 defect 可能被相鄰 patch 各預測一次。v2 會先把同一片 wafer 的所有 bbox 轉到完整 unwrap 全域座標，完成去重後才映射回原圖。

## 流程

```text
每張 patch 的 YOLO bbox
        ↓
依檔名取得 patch_index
        ↓
start_x = patch_index × stride
        ↓
轉成完整 unwrap bbox
        ↓
同類別 circular NMS / IoS 去重
        ↓
保留 confidence 較高的 bbox
        ↓
映射回原圖曲線 polygon
        ↓
輸出 visualization、mask、JSON
```

## 資料夾

```text
wafer_patch_bbox_mapper_v2/
├── original_images/
│   ├── wafer_001.png
│   └── wafer_002.png
├── prediction_labels/
│   ├── wafer_001_p0000.txt
│   ├── wafer_001_p0001.txt
│   ├── wafer_001_p0012.txt
│   └── wafer_002_p0003.txt
├── map_predictions.py
├── config.yaml
├── requirements.txt
└── README.md
```

Prediction TXT 支援：

```text
class_id center_x center_y width height
```

或：

```text
class_id center_x center_y width height confidence
```

所有 bbox 座標必須是 normalized YOLO 格式。

## 安裝與執行

```bash
pip install -r requirements.txt
python map_predictions.py --config config.yaml
```

## NMS 設定

```yaml
enable_global_nms: true
global_nms_iou: 0.5
use_ios: true
global_nms_ios: 0.8
min_confidence: 0.0
```

### global_nms_iou

```text
0.3：去重較積極，可能誤刪相鄰真實缺陷
0.5：建議起始值
0.7：去重較保守，可能留下部分重複框
```

### global_nms_ios

IoS 定義為：

```text
intersection / min(area_a, area_b)
```

若一個小框幾乎被另一個大框包含，兩者 IoU 可能不高，但 IoS 會很高。因此 v2 預設同時使用 IoU 與 IoS：

```text
IoU >= global_nms_iou
或
IoS >= global_nms_ios
```

即視為重複預測。

### class-wise

只有同類別互相去重：

```text
Lowfill vs Lowfill：會比較
Lowfill vs Splash：不會互相刪除
```

## Circular seam

對 0°／360° 附近的框，程式會將候選 bbox 分別平移：

```text
-unwrap_width
0
+unwrap_width
```

再取最大的 overlap，因此 359° 與 1° 的重複預測也能被判斷。

## 輸出

```text
mapped_results/
├── visualizations/
├── masks/
├── json/
└── summary.json
```

Terminal 會顯示：

```text
[完成] wafer_001: 18 → 10
```

表示 NMS 前有 18 個 prediction，去重後剩 10 個。

每片 wafer 的 JSON 會保存：

```json
{
  "raw_prediction_count": 18,
  "final_prediction_count": 10,
  "nms_enabled": true,
  "nms_iou": 0.5,
  "nms_ios": 0.8
}
```

## 建議測試

先選一片有重複框的 wafer，分別測試：

```yaml
global_nms_iou: 0.3
```

```yaml
global_nms_iou: 0.5
```

```yaml
global_nms_iou: 0.7
```

並比較 `mapped_results/visualizations/` 和 `mapped_results/json/`。選擇能去除重複框、但不會誤刪相鄰真實缺陷的設定。
