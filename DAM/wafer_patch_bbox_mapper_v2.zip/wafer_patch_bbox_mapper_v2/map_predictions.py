"""
map_predictions.py

將 YOLO 在 unwrap patch 上的 bbox 映射回原始 wafer，並使用
class-wise circular NMS 去除 overlap patch 造成的重複預測。

假設：
1. 檔名格式為 wafer_001_p0012.txt。
2. start_x = patch_index * stride。
3. unwrap 從原圖 12 點鐘方向開始。
4. unwrap 水平方向向右對應順時針。
5. unwrap 上方為 outer_radius，下方為 inner_radius。
"""

from __future__ import annotations

import argparse
import json
import re
from collections import defaultdict
from dataclasses import asdict, dataclass
from pathlib import Path

import cv2
import numpy as np
import yaml


IMAGE_SUFFIXES = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"}


@dataclass
class Config:
    original_image_dir: str = "original_images"
    prediction_dir: str = "prediction_labels"
    output_dir: str = "mapped_results"

    center_x: float = 2500.0
    center_y: float = 2500.0
    inner_radius: float = 2052.0
    outer_radius: float = 2500.0

    unwrap_width: int = 15708
    unwrap_height: int = 448
    patch_width: int = 1024
    stride: int = 512

    samples_per_side: int = 32
    class_names: tuple[str, ...] = ("Lowfill", "Overfill", "Splash")
    line_thickness: int = 3

    save_class_masks: bool = True
    save_merged_mask: bool = True

    # 跨 patch 去重設定
    enable_global_nms: bool = True
    global_nms_iou: float = 0.5
    global_nms_ios: float = 0.8
    use_ios: bool = True
    min_confidence: float = 0.0


@dataclass
class Prediction:
    class_id: int
    center_x: float
    center_y: float
    width: float
    height: float
    confidence: float = 1.0


@dataclass
class GlobalDetection:
    """完整 unwrap 連續座標中的 bbox。"""

    class_id: int
    confidence: float
    patch_index: int
    prediction_file: str
    x1: float
    y1: float
    x2: float
    y2: float
    prediction: Prediction


def load_config(path: str | Path) -> Config:
    with open(path, "r", encoding="utf-8") as file:
        raw = yaml.safe_load(file) or {}

    if "class_names" in raw:
        raw["class_names"] = tuple(raw["class_names"])

    cfg = Config(**raw)

    if not 0.0 <= cfg.global_nms_iou <= 1.0:
        raise ValueError("global_nms_iou 必須介於 0～1")
    if not 0.0 <= cfg.global_nms_ios <= 1.0:
        raise ValueError("global_nms_ios 必須介於 0～1")
    if cfg.inner_radius >= cfg.outer_radius:
        raise ValueError("inner_radius 必須小於 outer_radius")
    if cfg.patch_width <= 0 or cfg.stride <= 0:
        raise ValueError("patch_width 與 stride 必須大於 0")

    return cfg


def parse_patch_name(path: str | Path) -> tuple[str, int]:
    """wafer_001_p0012.txt -> (wafer_001, 12)。"""
    stem = Path(path).stem
    match = re.fullmatch(r"(?P<source>.+)_p(?P<index>\d+)", stem)

    if match is None:
        raise ValueError(f"檔名不符合 '<原圖名稱>_p<index>'：{stem}")

    return match.group("source"), int(match.group("index"))


def find_original_image(original_image_dir: str | Path, source_stem: str) -> Path:
    directory = Path(original_image_dir)
    if not directory.exists():
        raise FileNotFoundError(f"原圖資料夾不存在：{directory}")

    matches = [
        path
        for path in directory.iterdir()
        if path.is_file()
        and path.suffix.lower() in IMAGE_SUFFIXES
        and path.stem == source_stem
    ]

    if not matches:
        raise FileNotFoundError(f"找不到原圖：{source_stem}")
    if len(matches) > 1:
        raise RuntimeError(f"找到多張同 stem 原圖：{matches}")

    return matches[0]


def load_prediction_txt(txt_path: str | Path) -> list[Prediction]:
    """讀取 normalized YOLO bbox；支援有或無 confidence。"""
    path = Path(txt_path)
    predictions: list[Prediction] = []

    for line_no, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        line = line.strip()
        if not line:
            continue

        parts = line.split()
        if len(parts) == 5:
            class_id, cx, cy, width, height = parts
            confidence = 1.0
        elif len(parts) == 6:
            class_id, cx, cy, width, height, confidence = parts
        else:
            raise ValueError(f"{path}:{line_no} 欄位數必須是 5 或 6")

        predictions.append(
            Prediction(
                class_id=int(float(class_id)),
                center_x=float(cx),
                center_y=float(cy),
                width=float(width),
                height=float(height),
                confidence=float(confidence),
            )
        )

    return predictions


def yolo_bbox_to_patch_xyxy(
    prediction: Prediction,
    patch_width: int,
    patch_height: int,
) -> np.ndarray:
    cx = prediction.center_x * patch_width
    cy = prediction.center_y * patch_height
    box_width = prediction.width * patch_width
    box_height = prediction.height * patch_height

    return np.asarray(
        [
            np.clip(cx - box_width / 2.0, 0.0, patch_width - 1.0),
            np.clip(cy - box_height / 2.0, 0.0, patch_height - 1.0),
            np.clip(cx + box_width / 2.0, 0.0, patch_width - 1.0),
            np.clip(cy + box_height / 2.0, 0.0, patch_height - 1.0),
        ],
        dtype=np.float32,
    )


def prediction_to_global_detection(
    prediction: Prediction,
    patch_index: int,
    prediction_file: str,
    cfg: Config,
) -> GlobalDetection:
    """
    將 patch-local bbox 轉成完整 unwrap 的連續座標。

    x 暫時不 modulo，讓跨 0°/360° 的 bbox 保持連續。
    """
    local_x1, local_y1, local_x2, local_y2 = yolo_bbox_to_patch_xyxy(
        prediction,
        cfg.patch_width,
        cfg.unwrap_height,
    )
    start_x = patch_index * cfg.stride

    return GlobalDetection(
        class_id=prediction.class_id,
        confidence=prediction.confidence,
        patch_index=patch_index,
        prediction_file=prediction_file,
        x1=float(start_x + local_x1),
        y1=float(local_y1),
        x2=float(start_x + local_x2),
        y2=float(local_y2),
        prediction=prediction,
    )


def box_overlap_metrics(
    box_a: tuple[float, float, float, float],
    box_b: tuple[float, float, float, float],
) -> tuple[float, float]:
    """回傳 IoU 與 IoS（intersection / smaller area）。"""
    ax1, ay1, ax2, ay2 = box_a
    bx1, by1, bx2, by2 = box_b

    ix1 = max(ax1, bx1)
    iy1 = max(ay1, by1)
    ix2 = min(ax2, bx2)
    iy2 = min(ay2, by2)

    intersection_width = max(0.0, ix2 - ix1)
    intersection_height = max(0.0, iy2 - iy1)
    intersection = intersection_width * intersection_height

    area_a = max(0.0, ax2 - ax1) * max(0.0, ay2 - ay1)
    area_b = max(0.0, bx2 - bx1) * max(0.0, by2 - by1)
    union = area_a + area_b - intersection
    smaller_area = min(area_a, area_b)

    iou = intersection / union if union > 0 else 0.0
    ios = intersection / smaller_area if smaller_area > 0 else 0.0
    return iou, ios


def circular_overlap_metrics(
    detection_a: GlobalDetection,
    detection_b: GlobalDetection,
    unwrap_width: int,
) -> tuple[float, float]:
    """考慮 circular seam，取三種平移中最大的 IoU 與 IoS。"""
    box_a = (detection_a.x1, detection_a.y1, detection_a.x2, detection_a.y2)
    best_iou = 0.0
    best_ios = 0.0

    for shift in (-unwrap_width, 0, unwrap_width):
        box_b = (
            detection_b.x1 + shift,
            detection_b.y1,
            detection_b.x2 + shift,
            detection_b.y2,
        )
        iou, ios = box_overlap_metrics(box_a, box_b)
        best_iou = max(best_iou, iou)
        best_ios = max(best_ios, ios)

    return best_iou, best_ios


def classwise_circular_nms(
    detections: list[GlobalDetection],
    cfg: Config,
) -> list[GlobalDetection]:
    """同類別 circular NMS；confidence 高者優先保留。"""
    kept: list[GlobalDetection] = []

    for class_id in sorted({detection.class_id for detection in detections}):
        current = [detection for detection in detections if detection.class_id == class_id]
        current.sort(key=lambda detection: detection.confidence, reverse=True)

        while current:
            best = current.pop(0)
            kept.append(best)
            remaining: list[GlobalDetection] = []

            for candidate in current:
                iou, ios = circular_overlap_metrics(
                    best,
                    candidate,
                    cfg.unwrap_width,
                )

                is_duplicate = iou >= cfg.global_nms_iou
                if cfg.use_ios:
                    is_duplicate = is_duplicate or ios >= cfg.global_nms_ios

                if not is_duplicate:
                    remaining.append(candidate)

            current = remaining

    return kept


def sample_global_bbox_boundary(
    detection: GlobalDetection,
    samples_per_side: int,
) -> np.ndarray:
    """在完整 unwrap bbox 四邊取樣。"""
    x1, y1, x2, y2 = detection.x1, detection.y1, detection.x2, detection.y2

    top = np.stack(
        [np.linspace(x1, x2, samples_per_side), np.full(samples_per_side, y1)],
        axis=1,
    )
    right = np.stack(
        [np.full(samples_per_side, x2), np.linspace(y1, y2, samples_per_side)],
        axis=1,
    )
    bottom = np.stack(
        [np.linspace(x2, x1, samples_per_side), np.full(samples_per_side, y2)],
        axis=1,
    )
    left = np.stack(
        [np.full(samples_per_side, x1), np.linspace(y2, y1, samples_per_side)],
        axis=1,
    )

    return np.concatenate([top, right, bottom, left], axis=0).astype(np.float32)


def unwrapped_points_to_original(unwrap_points: np.ndarray, cfg: Config) -> np.ndarray:
    """12 點鐘起點、順時針、外徑在上。"""
    u = np.mod(unwrap_points[:, 0], cfg.unwrap_width)
    v = unwrap_points[:, 1]

    theta = -np.pi / 2.0 + 2.0 * np.pi * u / cfg.unwrap_width
    ratio = v / max(cfg.unwrap_height - 1, 1)
    radius = cfg.outer_radius - ratio * (cfg.outer_radius - cfg.inner_radius)

    original_x = cfg.center_x + radius * np.cos(theta)
    original_y = cfg.center_y + radius * np.sin(theta)

    return np.stack([original_x, original_y], axis=1).astype(np.float32)


def global_detection_to_original_polygon(
    detection: GlobalDetection,
    cfg: Config,
) -> np.ndarray:
    boundary = sample_global_bbox_boundary(detection, cfg.samples_per_side)
    return unwrapped_points_to_original(boundary, cfg)


def polygon_to_int(polygon: np.ndarray, image_shape: tuple[int, int]) -> np.ndarray:
    height, width = image_shape
    points = np.round(polygon).astype(np.int32)
    points[:, 0] = np.clip(points[:, 0], 0, width - 1)
    points[:, 1] = np.clip(points[:, 1], 0, height - 1)
    return points


def get_class_name(class_id: int, cfg: Config) -> str:
    if 0 <= class_id < len(cfg.class_names):
        return cfg.class_names[class_id]
    return f"class_{class_id}"


def get_draw_color(class_id: int) -> tuple[int, int, int]:
    palette = [
        (0, 0, 255),
        (0, 255, 255),
        (255, 0, 255),
        (255, 255, 0),
        (0, 255, 0),
        (255, 0, 0),
    ]
    return palette[class_id % len(palette)]


def draw_detection(
    canvas: np.ndarray,
    detection: GlobalDetection,
    polygon: np.ndarray,
    cfg: Config,
) -> None:
    points = polygon_to_int(polygon, canvas.shape[:2])
    color = get_draw_color(detection.class_id)

    cv2.polylines(
        canvas,
        [points.reshape(-1, 1, 2)],
        isClosed=True,
        color=color,
        thickness=cfg.line_thickness,
    )

    label = f"{get_class_name(detection.class_id, cfg)} {detection.confidence:.3f}"
    text_x = int(points[:, 0].min())
    text_y = int(points[:, 1].min())

    cv2.putText(
        canvas,
        label,
        (text_x, max(25, text_y - 6)),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.7,
        color,
        2,
        cv2.LINE_AA,
    )


def fill_polygon_mask(mask: np.ndarray, polygon: np.ndarray) -> None:
    points = polygon_to_int(polygon, mask.shape[:2])
    cv2.fillPoly(mask, [points.reshape(-1, 1, 2)], color=255)


def group_prediction_files(prediction_dir: str | Path) -> dict[str, list[Path]]:
    directory = Path(prediction_dir)
    if not directory.exists():
        raise FileNotFoundError(f"Prediction 資料夾不存在：{directory}")

    groups: dict[str, list[Path]] = defaultdict(list)
    for txt_path in sorted(directory.glob("*.txt")):
        source_stem, _ = parse_patch_name(txt_path)
        groups[source_stem].append(txt_path)

    return dict(groups)


def process_one_wafer(
    source_stem: str,
    prediction_files: list[Path],
    cfg: Config,
) -> dict:
    original_path = find_original_image(cfg.original_image_dir, source_stem)
    original = cv2.imread(str(original_path), cv2.IMREAD_COLOR)

    if original is None:
        raise FileNotFoundError(f"無法讀取原圖：{original_path}")

    # 先將同一片 wafer 的全部 patch prediction 收集到全域 unwrap 座標。
    all_detections: list[GlobalDetection] = []

    for prediction_file in sorted(prediction_files):
        _, patch_index = parse_patch_name(prediction_file)

        for prediction in load_prediction_txt(prediction_file):
            if prediction.confidence < cfg.min_confidence:
                continue

            all_detections.append(
                prediction_to_global_detection(
                    prediction=prediction,
                    patch_index=patch_index,
                    prediction_file=prediction_file.name,
                    cfg=cfg,
                )
            )

    # 所有 patch 收集完成後才做跨 patch NMS。
    if cfg.enable_global_nms:
        final_detections = classwise_circular_nms(all_detections, cfg)
    else:
        final_detections = all_detections

    output_root = Path(cfg.output_dir)
    visualization_dir = output_root / "visualizations"
    mask_dir = output_root / "masks"
    json_dir = output_root / "json"

    for directory in (visualization_dir, mask_dir, json_dir):
        directory.mkdir(parents=True, exist_ok=True)

    canvas = original.copy()
    merged_mask = np.zeros(original.shape[:2], dtype=np.uint8)
    class_masks: dict[int, np.ndarray] = {
        class_id: np.zeros(original.shape[:2], dtype=np.uint8)
        for class_id in range(len(cfg.class_names))
    }

    output_predictions: list[dict] = []

    # NMS 後才映射回原圖並畫圖。
    for detection in final_detections:
        polygon = global_detection_to_original_polygon(detection, cfg)
        draw_detection(canvas, detection, polygon, cfg)
        fill_polygon_mask(merged_mask, polygon)

        class_masks.setdefault(
            detection.class_id,
            np.zeros(original.shape[:2], dtype=np.uint8),
        )
        fill_polygon_mask(class_masks[detection.class_id], polygon)

        output_predictions.append(
            {
                "source_name": original_path.name,
                "prediction_file": detection.prediction_file,
                "patch_index": detection.patch_index,
                "start_x": detection.patch_index * cfg.stride,
                "class_id": detection.class_id,
                "class_name": get_class_name(detection.class_id, cfg),
                "confidence": detection.confidence,
                "global_unwrap_bbox": {
                    "x1": detection.x1,
                    "y1": detection.y1,
                    "x2": detection.x2,
                    "y2": detection.y2,
                },
                "original_polygon": polygon.tolist(),
            }
        )

    visualization_path = visualization_dir / f"{source_stem}_mapped.png"
    cv2.imwrite(str(visualization_path), canvas)

    if cfg.save_merged_mask:
        cv2.imwrite(str(mask_dir / f"{source_stem}_all.png"), merged_mask)

    if cfg.save_class_masks:
        for class_id, class_mask in class_masks.items():
            class_name = get_class_name(class_id, cfg)
            cv2.imwrite(str(mask_dir / f"{source_stem}_{class_name}.png"), class_mask)

    json_path = json_dir / f"{source_stem}.json"
    json_path.write_text(
        json.dumps(
            {
                "source_image": str(original_path),
                "raw_prediction_count": len(all_detections),
                "final_prediction_count": len(final_detections),
                "nms_enabled": cfg.enable_global_nms,
                "nms_iou": cfg.global_nms_iou,
                "nms_ios": cfg.global_nms_ios,
                "use_ios": cfg.use_ios,
                "config": asdict(cfg),
                "predictions": output_predictions,
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

    return {
        "source_stem": source_stem,
        "raw_prediction_count": len(all_detections),
        "final_prediction_count": len(final_detections),
        "visualization_path": str(visualization_path),
        "json_path": str(json_path),
    }


def main() -> None:
    parser = argparse.ArgumentParser(
        description="將 unwrap patch YOLO bbox 去重並映射回原始 wafer"
    )
    parser.add_argument("--config", default="config.yaml")
    args = parser.parse_args()

    cfg = load_config(args.config)
    groups = group_prediction_files(cfg.prediction_dir)

    if not groups:
        raise FileNotFoundError(f"在 {cfg.prediction_dir} 找不到 prediction TXT")

    summaries = []
    for source_stem, prediction_files in groups.items():
        summary = process_one_wafer(source_stem, prediction_files, cfg)
        summaries.append(summary)
        print(
            f"[完成] {source_stem}: "
            f"{summary['raw_prediction_count']} → "
            f"{summary['final_prediction_count']}"
        )

    output_root = Path(cfg.output_dir)
    output_root.mkdir(parents=True, exist_ok=True)
    (output_root / "summary.json").write_text(
        json.dumps(summaries, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    print(f"\n全部完成，結果位於：{output_root.resolve()}")


if __name__ == "__main__":
    main()
