from __future__ import annotations

import argparse
import json
import re
from collections import defaultdict
from dataclasses import asdict, dataclass
from pathlib import Path

import cv2
import numpy as np
import yaml

IMAGE_SUFFIXES = {'.png', '.jpg', '.jpeg', '.bmp', '.tif', '.tiff'}


@dataclass
class Config:
    original_image_dir: str = 'original_images'
    prediction_dir: str = 'prediction_labels'
    output_dir: str = 'mapped_results'
    center_x: float = 2500.0
    center_y: float = 2500.0
    inner_radius: float = 2052.0
    outer_radius: float = 2500.0
    unwrap_width: int = 15708
    unwrap_height: int = 448
    patch_width: int = 1024
    stride: int = 512
    samples_per_side: int = 32
    class_names: tuple[str, ...] = ('Lowfill', 'Overfill', 'Splash')
    line_thickness: int = 3
    save_class_masks: bool = True
    save_merged_mask: bool = True


@dataclass
class Prediction:
    class_id: int
    center_x: float
    center_y: float
    width: float
    height: float
    confidence: float = 1.0


def load_config(path: str | Path) -> Config:
    with open(path, 'r', encoding='utf-8') as f:
        raw = yaml.safe_load(f) or {}
    if 'class_names' in raw:
        raw['class_names'] = tuple(raw['class_names'])
    cfg = Config(**raw)
    if cfg.inner_radius >= cfg.outer_radius:
        raise ValueError('inner_radius 必須小於 outer_radius')
    if cfg.patch_width <= 0 or cfg.stride <= 0:
        raise ValueError('patch_width 與 stride 必須大於 0')
    return cfg


def parse_patch_name(path: str | Path) -> tuple[str, int]:
    stem = Path(path).stem
    m = re.fullmatch(r'(?P<source>.+)_p(?P<index>\d+)', stem)
    if m is None:
        raise ValueError(f"檔名不符合 '<原圖名稱>_p<patch index>'：{stem}")
    return m.group('source'), int(m.group('index'))


def find_original_image(original_image_dir: str | Path, source_stem: str) -> Path:
    directory = Path(original_image_dir)
    matches = [
        p for p in directory.iterdir()
        if p.is_file() and p.suffix.lower() in IMAGE_SUFFIXES and p.stem == source_stem
    ]
    if not matches:
        raise FileNotFoundError(f'在 {directory} 找不到原圖：{source_stem}')
    if len(matches) > 1:
        raise RuntimeError(f'找到多張同 stem 原圖：{matches}')
    return matches[0]


def load_prediction_txt(txt_path: str | Path) -> list[Prediction]:
    path = Path(txt_path)
    predictions: list[Prediction] = []
    for line_no, line in enumerate(path.read_text(encoding='utf-8').splitlines(), start=1):
        line = line.strip()
        if not line:
            continue
        parts = line.split()
        if len(parts) == 5:
            class_id, cx, cy, width, height = parts
            confidence = 1.0
        elif len(parts) == 6:
            class_id, cx, cy, width, height, confidence = parts
        else:
            raise ValueError(f'{path}:{line_no} 欄位數必須是 5 或 6')
        predictions.append(Prediction(
            class_id=int(float(class_id)),
            center_x=float(cx), center_y=float(cy),
            width=float(width), height=float(height),
            confidence=float(confidence),
        ))
    return predictions


def yolo_bbox_to_patch_xyxy(pred: Prediction, cfg: Config) -> np.ndarray:
    cx = pred.center_x * cfg.patch_width
    cy = pred.center_y * cfg.unwrap_height
    w = pred.width * cfg.patch_width
    h = pred.height * cfg.unwrap_height
    return np.array([
        np.clip(cx - w / 2, 0, cfg.patch_width - 1),
        np.clip(cy - h / 2, 0, cfg.unwrap_height - 1),
        np.clip(cx + w / 2, 0, cfg.patch_width - 1),
        np.clip(cy + h / 2, 0, cfg.unwrap_height - 1),
    ], dtype=np.float32)


def sample_bbox_boundary(xyxy: np.ndarray, n: int) -> np.ndarray:
    x1, y1, x2, y2 = xyxy
    top = np.stack([np.linspace(x1, x2, n), np.full(n, y1)], axis=1)
    right = np.stack([np.full(n, x2), np.linspace(y1, y2, n)], axis=1)
    bottom = np.stack([np.linspace(x2, x1, n), np.full(n, y2)], axis=1)
    left = np.stack([np.full(n, x1), np.linspace(y2, y1, n)], axis=1)
    return np.concatenate([top, right, bottom, left], axis=0).astype(np.float32)


def patch_points_to_unwrapped(points: np.ndarray, patch_index: int, cfg: Config) -> np.ndarray:
    start_x = patch_index * cfg.stride
    u = (start_x + points[:, 0]) % cfg.unwrap_width
    v = points[:, 1]
    return np.stack([u, v], axis=1).astype(np.float32)


def unwrapped_points_to_original(points: np.ndarray, cfg: Config) -> np.ndarray:
    u, v = points[:, 0], points[:, 1]
    theta = -np.pi / 2 + 2 * np.pi * u / cfg.unwrap_width
    ratio = v / max(cfg.unwrap_height - 1, 1)
    radius = cfg.outer_radius - ratio * (cfg.outer_radius - cfg.inner_radius)
    x = cfg.center_x + radius * np.cos(theta)
    y = cfg.center_y + radius * np.sin(theta)
    return np.stack([x, y], axis=1).astype(np.float32)


def prediction_to_original_polygon(pred: Prediction, patch_index: int, cfg: Config) -> np.ndarray:
    xyxy = yolo_bbox_to_patch_xyxy(pred, cfg)
    boundary = sample_bbox_boundary(xyxy, cfg.samples_per_side)
    unwrap_boundary = patch_points_to_unwrapped(boundary, patch_index, cfg)
    return unwrapped_points_to_original(unwrap_boundary, cfg)


def polygon_to_int(polygon: np.ndarray, shape: tuple[int, int]) -> np.ndarray:
    h, w = shape
    pts = np.round(polygon).astype(np.int32)
    pts[:, 0] = np.clip(pts[:, 0], 0, w - 1)
    pts[:, 1] = np.clip(pts[:, 1], 0, h - 1)
    return pts


def class_name(class_id: int, cfg: Config) -> str:
    return cfg.class_names[class_id] if 0 <= class_id < len(cfg.class_names) else f'class_{class_id}'


def color_for(class_id: int) -> tuple[int, int, int]:
    colors = [(0,0,255), (0,255,255), (255,0,255), (255,255,0), (0,255,0), (255,0,0)]
    return colors[class_id % len(colors)]


def group_prediction_files(prediction_dir: str | Path) -> dict[str, list[Path]]:
    groups: dict[str, list[Path]] = defaultdict(list)
    for txt in sorted(Path(prediction_dir).glob('*.txt')):
        source, _ = parse_patch_name(txt)
        groups[source].append(txt)
    return dict(groups)


def process_one_wafer(source: str, files: list[Path], cfg: Config) -> dict:
    original_path = find_original_image(cfg.original_image_dir, source)
    original = cv2.imread(str(original_path), cv2.IMREAD_COLOR)
    if original is None:
        raise FileNotFoundError(original_path)

    out = Path(cfg.output_dir)
    vis_dir, mask_dir, json_dir = out/'visualizations', out/'masks', out/'json'
    for d in (vis_dir, mask_dir, json_dir):
        d.mkdir(parents=True, exist_ok=True)

    canvas = original.copy()
    merged_mask = np.zeros(original.shape[:2], dtype=np.uint8)
    class_masks: dict[int, np.ndarray] = {}
    records = []

    for txt in sorted(files):
        _, patch_index = parse_patch_name(txt)
        for pred in load_prediction_txt(txt):
            polygon = prediction_to_original_polygon(pred, patch_index, cfg)
            pts = polygon_to_int(polygon, original.shape[:2])
            color = color_for(pred.class_id)
            cv2.polylines(canvas, [pts.reshape(-1,1,2)], True, color, cfg.line_thickness)
            tx, ty = int(pts[:,0].min()), int(pts[:,1].min())
            cv2.putText(canvas, f'{class_name(pred.class_id,cfg)} {pred.confidence:.3f}',
                        (tx, max(25, ty-6)), cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2, cv2.LINE_AA)
            cv2.fillPoly(merged_mask, [pts.reshape(-1,1,2)], 255)
            class_masks.setdefault(pred.class_id, np.zeros(original.shape[:2], dtype=np.uint8))
            cv2.fillPoly(class_masks[pred.class_id], [pts.reshape(-1,1,2)], 255)
            records.append({
                'source_name': original_path.name,
                'prediction_file': txt.name,
                'patch_index': patch_index,
                'start_x': patch_index * cfg.stride,
                'class_id': pred.class_id,
                'class_name': class_name(pred.class_id, cfg),
                'confidence': pred.confidence,
                'yolo_bbox': {'center_x': pred.center_x, 'center_y': pred.center_y,
                              'width': pred.width, 'height': pred.height},
                'original_polygon': polygon.tolist(),
            })

    vis_path = vis_dir / f'{source}_mapped.png'
    cv2.imwrite(str(vis_path), canvas)
    if cfg.save_merged_mask:
        cv2.imwrite(str(mask_dir / f'{source}_all.png'), merged_mask)
    if cfg.save_class_masks:
        for cid, mask in class_masks.items():
            cv2.imwrite(str(mask_dir / f'{source}_{class_name(cid,cfg)}.png'), mask)

    json_path = json_dir / f'{source}.json'
    json_path.write_text(json.dumps({
        'source_image': str(original_path),
        'config': asdict(cfg),
        'predictions': records,
    }, ensure_ascii=False, indent=2), encoding='utf-8')

    return {'source_stem': source, 'prediction_count': len(records),
            'visualization_path': str(vis_path), 'json_path': str(json_path)}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', default='config.yaml')
    args = parser.parse_args()
    cfg = load_config(args.config)
    groups = group_prediction_files(cfg.prediction_dir)
    if not groups:
        raise FileNotFoundError(f'在 {cfg.prediction_dir} 找不到 TXT')
    summaries = []
    for source, files in groups.items():
        summary = process_one_wafer(source, files, cfg)
        summaries.append(summary)
        print(f"[完成] {source}: {summary['prediction_count']} predictions")
    out = Path(cfg.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    (out/'summary.json').write_text(json.dumps(summaries, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f'\n全部完成：{out.resolve()}')


if __name__ == '__main__':
    main()
