# Wafer Patch BBox Mapper v1

這份程式將 YOLO 在 **unwrap patch** 上的 detection bbox 映射回原始 wafer 大圖。

目前不使用 metadata，而是從檔名解析原圖名稱與 patch index。例如：

```text
wafer_001_p0012.txt
```

會解析為：

```text
原圖名稱：wafer_001
patch index：12
start_x = 12 × stride
```

## 1. 座標假設

程式依照以下 polar unwrap 規則：

```text
u=0：原圖 12 點鐘方向
unwrap 向右：沿 wafer 順時針
v=0：outer_radius
v=unwrap_height-1：inner_radius
```

對應 forward transform 應類似：

```python
theta = np.linspace(
    -np.pi / 2,
    3 * np.pi / 2,
    output_width,
    endpoint=False,
)

radius = np.linspace(
    outer_radius,
    inner_radius,
    output_height,
)
```

## 2. 資料夾擺放

```text
wafer_patch_bbox_mapper_v1/
├── original_images/
│   ├── wafer_001.png
│   └── wafer_002.png
├── prediction_labels/
│   ├── wafer_001_p0000.txt
│   ├── wafer_001_p0001.txt
│   ├── wafer_001_p0012.txt
│   └── wafer_002_p0003.txt
├── map_predictions.py
├── config.yaml
├── requirements.txt
└── README.md
```

Prediction 檔名必須符合：

```text
<原圖 stem>_p<patch index>.txt
```

例如 `wafer_001_p0012.txt` 會尋找 `original_images/wafer_001.*`。

## 3. Prediction TXT 格式

支援 normalized YOLO bbox。

沒有 confidence：

```text
class_id center_x center_y width height
```

有 confidence：

```text
class_id center_x center_y width height confidence
```

例如：

```text
0 0.200000 0.400000 0.050000 0.100000 0.880000
1 0.550000 0.450000 0.080000 0.120000 0.930000
2 0.800000 0.300000 0.030000 0.040000 0.760000
```

## 4. 安裝

```bash
pip install -r requirements.txt
```

## 5. 修改 config.yaml

這些參數必須與建立 unwrap 與 patch 時完全一致：

```yaml
center_x: 2500
center_y: 2500
inner_radius: 2052
outer_radius: 2500
unwrap_width: 15708
unwrap_height: 448
patch_width: 1024
stride: 512
```

類別順序：

```yaml
class_names:
  - Lowfill
  - Overfill
  - Splash
```

對應：

```text
0 = Lowfill
1 = Overfill
2 = Splash
```

## 6. 執行

```bash
python map_predictions.py --config config.yaml
```

程式流程：

```text
讀取 prediction TXT
→ 解析 wafer 名稱與 patch index
→ start_x = patch_index × stride
→ YOLO bbox 轉 patch pixel bbox
→ patch 座標轉完整 unwrap 座標
→ unwrap 座標映射回原圖
→ 輸出 polygon、mask 與 JSON
```

## 7. 輸出

```text
mapped_results/
├── visualizations/
│   └── wafer_001_mapped.png
├── masks/
│   ├── wafer_001_all.png
│   ├── wafer_001_Lowfill.png
│   ├── wafer_001_Overfill.png
│   └── wafer_001_Splash.png
├── json/
│   └── wafer_001.json
└── summary.json
```

映射後 bbox 不再是普通矩形，而是環形扇區。程式會對 bbox 四條邊取樣，再畫成曲線 polygon。

## 8. Patch index 的計算

例如：

```text
wafer_001_p0012.txt
stride = 512
```

則：

```text
start_x = 12 × 512 = 6144
```

Patch 局部座標轉完整 unwrap 座標：

```text
global_u = (start_x + local_x) % unwrap_width
global_v = local_y
```

Modulo 用來處理最後 patch 跨越 360°/0° 接縫。

## 9. 初版限制

目前沒有跨 patch NMS。因為 `patch_width=1024`、`stride=512` 有 50% overlap，同一 defect 可能在相鄰 patch 被預測兩次，映射後會看到重複 polygon。

建議先確認映射的位置與方向正確，再加入 unwrap global coordinate NMS。

## 10. 常見問題

### 結果旋轉 90 度

確認 forward theta 是從 `-π/2` 開始，也就是 12 點鐘。

### 順時針與逆時針相反

目前假設 unwrap 向右等於原圖順時針。如果你的 theta 遞減，需要修改反向角度公式。

### 內外徑上下顛倒

目前假設 forward radius 使用：

```python
np.linspace(outer_radius, inner_radius, output_height)
```

### 結果偏移一個 patch

確認 patch 檔名 index 是原本 `enumerate(range(0, unwrap_width, stride))` 的 index，且沒有刪除後重新編號。

## 11. 建議第一次測試

先只保留一個容易辨認的 prediction：

```text
prediction_labels/wafer_001_p0012.txt
```

執行後檢查：

```text
mapped_results/visualizations/wafer_001_mapped.png
```

確認角度、內外徑與 bbox 寬高正確後，再加入全部 inference 結果。
